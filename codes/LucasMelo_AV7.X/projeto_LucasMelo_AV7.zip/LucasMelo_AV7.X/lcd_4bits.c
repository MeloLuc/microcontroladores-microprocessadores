/* ########################################################################

   PICsim - PIC simulator http://sourceforge.net/projects/picsim/

   ########################################################################

   Copyright (c) : 2015  Luis Claudio Gamb�a Lopes

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   For e-mail suggestions :  lcgamboa@yahoo.com
   ######################################################################## */

#include <xc.h>
#include "config.h"
#include "lcd_4bits.h"

// Envia 4 bits para o barramento de dados do LCD
void lcd_wr_nibble(unsigned char nibble) {
    LPORT = (LPORT & 0x0F) | (nibble & 0xF0); // assume que os pinos D4-D7 est�o nos bits 4-7

//           NIBBLE MSD        NIBBLE LSB
// PORTD = RD7 RD6 RD5 RD4 | RD3 RD2 RD1 RD0
//    RD4 = (nibble >> 0) & 1;
//    RD5 = (nibble >> 1) & 1;
//    RD6 = (nibble >> 2) & 1;
//    RD7 = (nibble >> 3) & 1;
    
    LENA = 1;
    atraso_ms(1);
    LENA = 0;
    atraso_ms(1);
}



// Envia um comando de 8 bits (dividido em dois nibbles)
void lcd_cmd(unsigned char val) {
    LDAT = 0; // comando
    lcd_wr_nibble(val);         // envia os 4 MSB
    lcd_wr_nibble((unsigned char)(val << 4));    // envia os 4 LSB
}

// Envia um dado (caractere) de 8 bits (dividido em dois nibbles)
void lcd_dat(unsigned char val) {
    LDAT = 1; // dado
    lcd_wr_nibble(val);         // envia os 4 MSB
    lcd_wr_nibble((unsigned char)(val << 4));    // envia os 4 LSB
}

// Inicializa o LCD no modo 4 bits
void lcd_init(void) {
    LENA = 0;
    LDAT = 0;
    atraso_ms(20); // espera inicial

    // Sequ�ncia especial de inicializa��o para 4 bits
    lcd_wr_nibble(0x30); // modo 8 bits (repetido 3 vezes) RESET
    atraso_ms(5);
    lcd_wr_nibble(0x30);
    atraso_ms(1);
    lcd_wr_nibble(0x30);
    atraso_ms(1);
    lcd_wr_nibble(0x20); // muda para modo 4 bits
    atraso_ms(1);

    // Agora podemos usar comandos de 8 bits divididos em 2 nibbles
    lcd_cmd(0x28); // interface 4 bits, 2 linhas, fonte 5x8
    lcd_cmd(0x08); // display off
    lcd_cmd(0x0C); // display on, cursor off, blink off
    lcd_cmd(0x06); // incremento autom�tico, sem shift
    lcd_cmd(0x01); // limpa display
    atraso_ms(2);
    lcd_cmd(0x80); // posi��o inicial (linha 1, coluna 0)
}

// Envia uma string para o LCD
void lcd_str(const char* str) {
    while (*str != '\0') {
        lcd_dat(*str++);
    }
}
