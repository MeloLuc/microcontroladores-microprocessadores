#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=Aciona_LED.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/Aciona_LED.X.production.hex
